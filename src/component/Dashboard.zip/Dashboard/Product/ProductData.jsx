import Allproduct from "./Allproduct";
import PendingApproval from "./PendingApproval";

const ProductData = [
 
  {
    content: <div><Allproduct /></div> ,
  },
  {
    content: <div><PendingApproval /></div> ,
  },
  {
    content: <div>number3</div> ,
  },
  {
    content: <div>number4</div> ,
  },
];
export default ProductData;