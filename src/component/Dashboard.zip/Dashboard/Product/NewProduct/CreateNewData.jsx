import Category from "./Category";

const NewProductData = [
 
  {
    content: <div><Category /></div> ,
  },
  {
    content: <div>number2</div> ,
  },
 
];
export default NewProductData;