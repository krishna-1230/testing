export const Prod = [
    {
        logo: "/navbar/Checkbox.svg",
        product_id: "#12435",
        product_name: "Tshirt",
        product_category: "Menswear",
        date: "24/10/24",
        merchant_id: "ABCD Shop",
        images: "/navbar/unsplash_3ZmngTqbaYQ.svg"
    },
    {
        logo: "/navbar/Checkbox.svg",
        product_id: "#12435",
        product_name: "Tshirt",
        product_category: "Menswear",
        date: "24/10/24",
        merchant_id: "ABCD Shop",
        images: "/navbar/unsplash_3ZmngTqbaYQ.svg"
    },
    {
        logo: "/navbar/Checkbox.svg",
        product_id: "#12435",
        product_name: "Tshirt",
        product_category: "Menswear",
        date: "24/10/24",
        merchant_id: "ABCD Shop",
        images: "/navbar/unsplash_3ZmngTqbaYQ.svg"
    },
    {
        logo: "/navbar/Checkbox.svg",
        product_id: "#12435",
        product_name: "Tshirt",
        product_category: "Menswear",
        date: "24/10/24",
        merchant_id: "ABCD Shop",
        images: "/navbar/unsplash_3ZmngTqbaYQ.svg"
    },
    {
        logo: "/navbar/Checkbox.svg",
        product_id: "#12435",
        product_name: "Tshirt",
        product_category: "Menswear",
        date: "24/10/24",
        merchant_id: "ABCD Shop",
        images: "/navbar/unsplash_3ZmngTqbaYQ.svg"
    },
    {
        logo: "/navbar/Checkbox.svg",
        product_id: "#12435",
        product_name: "Tshirt",
        product_category: "Menswear",
        date: "24/10/24",
        merchant_id: "ABCD Shop",
        images: "/navbar/unsplash_3ZmngTqbaYQ.svg"
    }

];
