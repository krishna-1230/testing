import ActiveOrder from "./ActiveOrder";


const OrderData = [
 
  {
    content: <div><ActiveOrder /></div> ,
  },
  {
    content: <div><ActiveOrder /></div> ,
  },
  {
    content: <div><ActiveOrder /></div> ,
  }
];
export default OrderData;